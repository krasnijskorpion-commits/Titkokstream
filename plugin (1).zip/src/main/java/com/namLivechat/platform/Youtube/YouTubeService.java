package com.namLivechat.platform.Youtube;

import com.google.api.services.youtube.model.LiveChatMessage;
import com.google.api.services.youtube.model.LiveChatMessageListResponse;
import com.namLivechat.NamLivechat;
import com.namLivechat.service.MessageHandler;
import com.namLivechat.service.PlayerTaskDispatcher;
import io.papermc.paper.threadedregions.scheduler.ScheduledTask;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitTask;

import java.util.ArrayList;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;

/** One YouTube poller per video, shared by every subscribed player. */
public final class YouTubeService {

    private final NamLivechat plugin;
    private final MessageHandler messages;
    private final PlayerTaskDispatcher dispatcher;
    private final YouTubeApiHelper apiHelper;
    private final Map<UUID, String> playerSessions = new ConcurrentHashMap<>();
    private final Map<String, YouTubeSession> sessions = new ConcurrentHashMap<>();

    public YouTubeService(NamLivechat plugin) {
        this.plugin = plugin;
        this.messages = plugin.getMessageHandler();
        this.dispatcher = plugin.getPlayerTaskDispatcher();
        this.apiHelper = new YouTubeApiHelper(plugin);
        initialize();
    }

    public void initialize() {
        apiHelper.initialize();
    }

    public void start(Player player, String input) {
        if (!plugin.getYoutubeConfig().getBoolean("enabled", false)) {
            messages.sendMessage(player, "youtube_disabled");
            player.playSound(player.getLocation(), "entity.villager.no", 1.0f, 1.0f);
            return;
        }
        if (!apiHelper.isAvailable()) {
            messages.sendMessage(player, "youtube_no_api_key");
            return;
        }
        if (isConnected(player)) {
            messages.sendFormattedMessage(player, "already_connected", "%platform%", "YouTube");
            return;
        }

        String extracted = apiHelper.getVideoIdFromUrl(input);
        String videoId = (extracted == null ? input : extracted).trim();
        if (!sessions.containsKey(videoId) && sessions.size() >= maxSessions()) {
            messages.sendMessage(player, "too_many_streams");
            return;
        }
        if (playerSessions.putIfAbsent(player.getUniqueId(), videoId) != null) return;

        YouTubeSession session = sessions.computeIfAbsent(videoId, YouTubeSession::new);
        session.add(player);
        session.start();
    }

    public boolean stop(Player player, boolean silent) {
        String videoId = playerSessions.remove(player.getUniqueId());
        if (videoId == null) return false;
        YouTubeSession session = sessions.get(videoId);
        if (session != null) session.remove(player.getUniqueId());
        plugin.getAlertService().stopBossBar(player);
        return true;
    }

    public void stopAll() {
        new ArrayList<>(sessions.values()).forEach(session -> session.close(false, null));
        playerSessions.clear();
        sessions.clear();
    }

    public boolean isConnected(Player player) {
        return playerSessions.containsKey(player.getUniqueId());
    }

    public String getVideoIdFromUrl(String url) {
        return apiHelper.getVideoIdFromUrl(url);
    }

    public int getSessionCount() {
        return sessions.size();
    }

    public int getSubscriberCount() {
        return playerSessions.size();
    }

    private int maxSessions() {
        return Math.max(1, plugin.getConfig().getInt("performance.max-shared-streams-per-platform", 50));
    }

    private void runAsync(Runnable runnable) {
        if (plugin.isDisabling()) return;
        if (plugin.isFolia()) Bukkit.getAsyncScheduler().runNow(plugin, ignored -> runnable.run());
        else Bukkit.getScheduler().runTaskAsynchronously(plugin, runnable);
    }

    private final class YouTubeSession {
        private final String videoId;
        private final Map<UUID, Subscriber> subscribers = new ConcurrentHashMap<>();
        private final AtomicBoolean started = new AtomicBoolean();
        private final AtomicBoolean closed = new AtomicBoolean();
        private volatile Object pollTask;
        private volatile String liveChatId;
        private volatile String channelTitle;
        private volatile String videoTitle;
        private volatile String nextPageToken;
        private volatile long lastMessageTimestamp;
        private volatile int failures;

        private YouTubeSession(String videoId) {
            this.videoId = videoId;
        }

        private void add(Player player) {
            Subscriber subscriber = new Subscriber(player, new YouTubeMessageProcessor(plugin, player));
            subscribers.put(player.getUniqueId(), subscriber);
            if (liveChatId != null) notifyConnected(subscriber);
        }

        private void remove(UUID playerId) {
            subscribers.remove(playerId);
            if (subscribers.isEmpty()) close(false, null);
        }

        private void start() {
            if (!started.compareAndSet(false, true)) return;
            runAsync(() -> {
                try {
                    LiveStreamInfo info = apiHelper.getLiveChatId(videoId);
                    if (closed.get() || subscribers.isEmpty()) return;
                    if (info == null) {
                        broadcast(subscriber -> messages.sendMessage(subscriber.player, "youtube_not_live"));
                        close(false, null);
                        return;
                    }
                    liveChatId = info.liveChatId();
                    channelTitle = info.channelTitle();
                    videoTitle = info.videoTitle();
                    lastMessageTimestamp = System.currentTimeMillis();
                    subscribers.values().forEach(this::notifyConnected);
                    poll();
                } catch (Exception error) {
                    handleConnectError(error);
                }
            });
        }

        private void poll() {
            if (closed.get() || subscribers.isEmpty()) return;
            try {
                LiveChatMessageListResponse response = apiHelper.getLiveChatMessages(liveChatId, nextPageToken);
                if (response == null) throw new IllegalStateException("YouTube returned an empty response");

                failures = 0;
                nextPageToken = response.getNextPageToken();
                long maximumTimestamp = lastMessageTimestamp;
                if (response.getItems() != null) {
                    for (LiveChatMessage item : response.getItems()) {
                        long timestamp = item.getSnippet().getPublishedAt().getValue();
                        if (timestamp <= lastMessageTimestamp) continue;
                        maximumTimestamp = Math.max(maximumTimestamp, timestamp);
                        subscribers.forEach((uuid, subscriber) -> dispatcher.dispatch(subscriber.player, () -> {
                            if (subscribers.containsKey(uuid)) subscriber.processor.handleMessage(item);
                        }));
                    }
                }
                lastMessageTimestamp = maximumTimestamp;
                long serverDelay = response.getPollingIntervalMillis() == null ? 1_000L : response.getPollingIntervalMillis();
                long minimumDelay = Math.max(250L,
                        plugin.getConfig().getLong("performance.youtube-min-poll-interval-millis", 1_000L));
                schedulePoll(Math.max(serverDelay, minimumDelay));
            } catch (Exception error) {
                failures++;
                plugin.logDebug("YouTube poll failed for " + videoId + " (" + failures + "): " + error.getMessage());
                int maximumFailures = Math.max(1,
                        plugin.getConfig().getInt("performance.max-consecutive-api-failures", 5));
                if (failures >= maximumFailures) {
                    close(true, "disconnect_stream_ended_youtube");
                } else {
                    schedulePoll(Math.min(30_000L, 1_000L << Math.min(5, failures)));
                }
            }
        }

        private void schedulePoll(long delayMillis) {
            if (closed.get()) return;
            if (plugin.isFolia()) {
                pollTask = Bukkit.getAsyncScheduler().runDelayed(plugin, ignored -> poll(), delayMillis, TimeUnit.MILLISECONDS);
            } else {
                pollTask = Bukkit.getScheduler().runTaskLaterAsynchronously(plugin, this::poll,
                        Math.max(1L, (delayMillis + 49L) / 50L));
            }
        }

        private void notifyConnected(Subscriber subscriber) {
            dispatcher.dispatch(subscriber.player, () -> {
                if (!subscribers.containsKey(subscriber.player.getUniqueId())) return;
                messages.sendFormattedMessage(subscriber.player, "connect_success_youtube",
                        "%title%", videoTitle,
                        "%channel%", channelTitle);
                subscriber.player.playSound(subscriber.player.getLocation(),
                        "entity.experience_orb.pickup", 1.0f, 1.0f);
            });
        }

        private void handleConnectError(Exception error) {
            String text = error.getMessage() == null ? "" : error.getMessage().toLowerCase();
            String message = null;
            if (text.contains("api key not valid") || text.contains("api_key_invalid")) message = "youtube_invalid_key";
            else if (text.contains("quotaexceeded")) message = "youtube_quota_exceeded";
            if (message != null) {
                String path = message;
                broadcast(subscriber -> messages.sendMessage(subscriber.player, path));
            }
            plugin.logDebug("YouTube connection failed for " + videoId + ": " + error.getMessage());
            close(false, null);
        }

        private void broadcast(java.util.function.Consumer<Subscriber> action) {
            subscribers.values().forEach(subscriber -> dispatcher.dispatch(subscriber.player, () -> action.accept(subscriber)));
        }

        private void close(boolean notifyEnded, String messagePath) {
            if (!closed.compareAndSet(false, true)) return;
            cancel(pollTask);
            sessions.remove(videoId, this);
            Map<UUID, Subscriber> snapshot = Map.copyOf(subscribers);
            subscribers.clear();
            snapshot.forEach((uuid, subscriber) -> {
                playerSessions.remove(uuid, videoId);
                dispatcher.dispatch(subscriber.player, () -> {
                    plugin.getAlertService().stopBossBar(subscriber.player);
                    if (notifyEnded && messagePath != null) {
                        messages.sendFormattedMessage(subscriber.player, messagePath,
                                "%channel%", channelTitle == null ? "YouTube" : channelTitle);
                    }
                });
            });
        }

        private void cancel(Object task) {
            if (task instanceof ScheduledTask scheduledTask) scheduledTask.cancel();
            else if (task instanceof BukkitTask bukkitTask) bukkitTask.cancel();
        }
    }

    private record Subscriber(Player player, YouTubeMessageProcessor processor) { }

    public record LiveStreamInfo(String liveChatId, String channelTitle, String videoTitle) { }
}
