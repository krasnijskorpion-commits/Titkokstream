package com.namLivechat.platform.Twitch;

import com.github.twitch4j.chat.events.channel.ChannelMessageEvent;

import java.util.function.Consumer;

/** Formats a Twitch event once before it is fanned out to all subscribers. */
public final class TwitchChatListener {

    private final TwitchMessageFormatter formatter;
    private final Consumer<String> consumer;

    public TwitchChatListener(TwitchMessageFormatter formatter, Consumer<String> consumer) {
        this.formatter = formatter;
        this.consumer = consumer;
    }

    public void onChannelMessage(ChannelMessageEvent event) {
        consumer.accept(formatter.format(event));
    }
}
