package com.namLivechat.platform.Twitch;

import com.github.twitch4j.TwitchClient;
import com.github.twitch4j.helix.domain.StreamList;
import com.namLivechat.NamLivechat;
import io.papermc.paper.threadedregions.scheduler.ScheduledTask;
import org.bukkit.Bukkit;
import org.bukkit.scheduler.BukkitTask;

import java.util.Collections;
import java.util.concurrent.TimeUnit;

/** Distinguishes an offline stream from a transient API failure. */
public final class TwitchStreamMonitor {

    private final NamLivechat plugin;
    private final TwitchClient client;
    private final String oauthToken;
    private final String channelName;
    private final Runnable onStreamEnd;
    private final long intervalSeconds;
    private volatile Object task;

    public TwitchStreamMonitor(NamLivechat plugin, TwitchClient client, String oauthToken,
                               String channelName, Runnable onStreamEnd, long intervalSeconds) {
        this.plugin = plugin;
        this.client = client;
        this.oauthToken = oauthToken;
        this.channelName = channelName;
        this.onStreamEnd = onStreamEnd;
        this.intervalSeconds = intervalSeconds;
    }

    public void start() {
        Runnable check = () -> {
            if (plugin.isDisabling()) {
                stop();
                return;
            }
            Boolean live = isStreamLive();
            if (Boolean.FALSE.equals(live)) {
                stop();
                onStreamEnd.run();
            }
        };
        if (plugin.isFolia()) {
            task = Bukkit.getAsyncScheduler().runAtFixedRate(plugin, ignored -> check.run(),
                    intervalSeconds, intervalSeconds, TimeUnit.SECONDS);
        } else {
            task = Bukkit.getScheduler().runTaskTimerAsynchronously(plugin, check,
                    intervalSeconds * 20L, intervalSeconds * 20L);
        }
    }

    private Boolean isStreamLive() {
        try {
            StreamList result = client.getHelix().getStreams(oauthToken, null, null, 1,
                    null, null, null, Collections.singletonList(channelName)).execute();
            return !result.getStreams().isEmpty();
        } catch (Exception error) {
            plugin.logDebug("Twitch stream check failed (will retry): " + error.getMessage());
            return null;
        }
    }

    public void stop() {
        Object current = task;
        task = null;
        if (current instanceof ScheduledTask scheduledTask) scheduledTask.cancel();
        else if (current instanceof BukkitTask bukkitTask) bukkitTask.cancel();
    }
}
