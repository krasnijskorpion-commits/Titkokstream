package com.namLivechat.platform.Twitch;

import com.namLivechat.NamLivechat;
import com.namLivechat.service.MessageHandler;
import org.bukkit.entity.Player;

import java.util.ArrayList;
import java.util.Locale;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/** Shares a single Twitch IRC/Helix client between viewers of the same channel. */
public final class TwitchService {

    private final NamLivechat plugin;
    private final MessageHandler messages;
    private final Map<UUID, String> playerSessions = new ConcurrentHashMap<>();
    private final Map<String, TwitchConnection> sessions = new ConcurrentHashMap<>();

    public TwitchService(NamLivechat plugin) {
        this.plugin = plugin;
        this.messages = plugin.getMessageHandler();
    }

    public void initialize() {
        // New sessions read the freshly loaded immutable values from the config.
    }

    public void start(Player player, String channelName) {
        if (!plugin.getTwitchConfig().getBoolean("enabled", false)) {
            messages.sendMessage(player, "twitch_disabled");
            player.playSound(player.getLocation(), "entity.villager.no", 1.0f, 1.0f);
            return;
        }
        if (isRunning(player)) {
            messages.sendFormattedMessage(player, "already_connected", "%platform%", "Twitch");
            return;
        }
        String oauthToken = plugin.getTwitchConfig().getString("oauth-token");
        if (oauthToken == null || oauthToken.isBlank() || oauthToken.equalsIgnoreCase("YOUR_OAUTH_TOKEN_HERE")) {
            messages.sendMessage(player, "twitch_no_token");
            return;
        }

        String channel = channelName.trim().toLowerCase(Locale.ROOT);
        if (!sessions.containsKey(channel) && sessions.size() >= maxSessions()) {
            messages.sendMessage(player, "too_many_streams");
            return;
        }
        if (playerSessions.putIfAbsent(player.getUniqueId(), channel) != null) return;

        TwitchConnection connection = sessions.computeIfAbsent(channel,
                key -> new TwitchConnection(plugin, key, this));
        connection.addPlayer(player);
        connection.start();
    }

    public boolean stop(Player player, boolean silent) {
        String channel = playerSessions.remove(player.getUniqueId());
        if (channel == null) return false;
        TwitchConnection connection = sessions.get(channel);
        if (connection != null) connection.removePlayer(player.getUniqueId());
        plugin.getAlertService().stopBossBar(player);
        return true;
    }

    public void stopAll() {
        new ArrayList<>(sessions.values()).forEach(TwitchConnection::stopManual);
        playerSessions.clear();
        sessions.clear();
    }

    public boolean isRunning(Player player) {
        return playerSessions.containsKey(player.getUniqueId());
    }

    void connectionClosed(String channel, TwitchConnection connection, Iterable<UUID> playerIds) {
        sessions.remove(channel, connection);
        playerIds.forEach(uuid -> playerSessions.remove(uuid, channel));
    }

    public int getSessionCount() {
        return sessions.size();
    }

    public int getSubscriberCount() {
        return playerSessions.size();
    }

    private int maxSessions() {
        return Math.max(1, plugin.getConfig().getInt("performance.max-shared-streams-per-platform", 50));
    }
}
