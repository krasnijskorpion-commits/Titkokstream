package com.namLivechat.platform.Twitch;

import com.github.philippheuer.credentialmanager.domain.OAuth2Credential;
import com.github.twitch4j.TwitchClient;
import com.github.twitch4j.TwitchClientBuilder;
import com.github.twitch4j.chat.events.channel.ChannelMessageEvent;
import com.github.twitch4j.chat.events.channel.GiftSubscriptionsEvent;
import com.github.twitch4j.chat.events.channel.SubscriptionEvent;
import com.github.twitch4j.helix.domain.Stream;
import com.github.twitch4j.helix.domain.StreamList;
import com.namLivechat.NamLivechat;
import com.namLivechat.service.MessageHandler;
import com.namLivechat.service.PlayerTaskDispatcher;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.boss.BarColor;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Player;

import java.util.Collections;
import java.util.Locale;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicBoolean;

/** A shared Twitch session. One client, IRC join and monitor set serves a channel. */
public final class TwitchConnection {

    private final NamLivechat plugin;
    private final String channelName;
    private final TwitchService owner;
    private final MessageHandler messages;
    private final PlayerTaskDispatcher dispatcher;
    private final String oauthToken;
    private final Map<UUID, Player> subscribers = new ConcurrentHashMap<>();
    private final AtomicBoolean started = new AtomicBoolean();
    private final AtomicBoolean closed = new AtomicBoolean();
    private volatile TwitchClient client;
    private volatile TwitchStreamMonitor streamMonitor;
    private volatile TwitchFollowerMonitor followerMonitor;
    private volatile String streamTitle;
    private volatile String streamerName;

    public TwitchConnection(NamLivechat plugin, String channelName, TwitchService owner) {
        this.plugin = plugin;
        this.channelName = channelName;
        this.owner = owner;
        this.messages = plugin.getMessageHandler();
        this.dispatcher = plugin.getPlayerTaskDispatcher();
        this.oauthToken = plugin.getTwitchConfig().getString("oauth-token");
    }

    public void addPlayer(Player player) {
        subscribers.put(player.getUniqueId(), player);
        if (streamerName != null) notifyConnected(player);
    }

    public void removePlayer(UUID playerId) {
        subscribers.remove(playerId);
        if (subscribers.isEmpty()) stopManual();
    }

    public void start() {
        if (!started.compareAndSet(false, true)) return;
        runAsync(() -> {
            try {
                client = TwitchClientBuilder.builder()
                        .withEnableHelix(true)
                        .withEnableChat(true)
                        .withChatAccount(new OAuth2Credential("twitch", oauthToken))
                        .withChatCommandsViaHelix(false)
                        .withDefaultAuthToken(new OAuth2Credential("twitch", oauthToken))
                        .build();
                if (closed.get()) {
                    client.close();
                    return;
                }

                Stream stream = getStream();
                if (closed.get() || subscribers.isEmpty()) {
                    client.close();
                    return;
                }
                if (stream == null) {
                    cleanup(false, player -> {
                            messages.sendFormattedMessage(player, "twitch_not_live", "%channel%", channelName);
                            player.playSound(player.getLocation(), "entity.villager.no", 1.0f, 1.0f);
                        });
                    return;
                }

                streamTitle = stream.getTitle();
                streamerName = stream.getUserName();
                client.getChat().joinChannel(channelName);
                registerEventListeners();
                subscribers.values().forEach(this::notifyConnected);

                long streamSeconds = Math.max(15L,
                        plugin.getConfig().getLong("performance.twitch-stream-poll-seconds", 60L));
                streamMonitor = new TwitchStreamMonitor(plugin, client, oauthToken, channelName,
                        this::stopDueToStreamEnd, streamSeconds);
                streamMonitor.start();

                if (plugin.getTwitchConfig().getBoolean("events.new-follower.enabled", true)) {
                    long followerSeconds = Math.max(15L,
                            plugin.getConfig().getLong("performance.twitch-follower-poll-seconds", 60L));
                    followerMonitor = new TwitchFollowerMonitor(plugin, client, oauthToken, stream.getUserId(),
                            this::handleNewFollower, followerSeconds);
                    followerMonitor.start();
                }
            } catch (Exception error) {
                String text = error.getMessage() == null ? "" : error.getMessage().toLowerCase(Locale.ROOT);
                if (text.contains("login authentication failed") || text.contains("invalid irc credentials")) {
                    cleanup(false, player -> messages.sendMessage(player, "twitch_invalid_token"));
                } else {
                    plugin.logDebug("Twitch connection failed for " + channelName + ": " + error.getMessage());
                    cleanup(false, player -> messages.sendMessage(player, "twitch_connect_fail"));
                }
            }
        });
    }

    public void stopManual() {
        if (plugin.isDisabling()) cleanup(false, null);
        else runAsync(() -> cleanup(false, null));
    }

    private void stopDueToStreamEnd() {
        cleanup(true, null);
    }

    private void cleanup(boolean streamEnded, java.util.function.Consumer<Player> terminalMessage) {
        if (!closed.compareAndSet(false, true)) return;
        if (streamMonitor != null) streamMonitor.stop();
        if (followerMonitor != null) followerMonitor.stop();
        if (client != null) {
            try {
                client.close();
            } catch (Exception error) {
                plugin.logDebug("Twitch close failed for " + channelName + ": " + error.getMessage());
            }
        }

        Map<UUID, Player> snapshot = Map.copyOf(subscribers);
        subscribers.clear();
        owner.connectionClosed(channelName, this, snapshot.keySet());
        snapshot.values().forEach(player -> dispatcher.dispatch(player, () -> {
            plugin.getAlertService().stopBossBar(player);
            if (terminalMessage != null) terminalMessage.accept(player);
            if (streamEnded) {
                messages.sendFormattedMessage(player, "disconnect_stream_ended_twitch",
                        "%channel%", streamerName == null ? channelName : streamerName);
            }
        }));
    }

    private void notifyConnected(Player player) {
        dispatcher.dispatch(player, () -> {
            if (!subscribers.containsKey(player.getUniqueId())) return;
            messages.sendFormattedMessage(player, "connect_success_twitch",
                    "%title%", streamTitle,
                    "%channel%", streamerName);
            player.playSound(player.getLocation(), "entity.experience_orb.pickup", 1.0f, 1.0f);
        });
    }

    private void registerEventListeners() {
        FileConfiguration config = plugin.getTwitchConfig();
        TwitchChatListener chat = new TwitchChatListener(new TwitchMessageFormatter(config), this::broadcastMessage);
        client.getEventManager().onEvent(ChannelMessageEvent.class, chat::onChannelMessage);
        if (!config.getBoolean("events.enabled", true)) return;

        client.getEventManager().onEvent(SubscriptionEvent.class, event -> {
            if (closed.get() || !event.getChannel().getName().equalsIgnoreCase(channelName)) return;
            String type = null;
            if (event.getGifted() && event.getGiftedBy() != null
                    && config.getBoolean("events.gift-subscription.enabled", true)) type = "gift-subscription";
            else if (!event.getGifted() && event.getMonths() > 1
                    && config.getBoolean("events.resubscription.enabled", true)) type = "resubscription";
            else if (!event.getGifted() && event.getMonths() <= 1
                    && config.getBoolean("events.new-subscription.enabled", true)) type = "new-subscription";
            if (type == null) return;
            String path = "events." + type;
            broadcastAlert(
                    replace(config.getString(path + ".message", ""), event, null),
                    replace(config.getString(path + ".boss-bar.message", ""), event, null),
                    path,
                    type);
        });

        if (config.getBoolean("events.community-subscription.enabled", true)) {
            client.getEventManager().onEvent(GiftSubscriptionsEvent.class, event -> {
                if (closed.get() || !event.getChannel().getName().equalsIgnoreCase(channelName)) return;
                String type = "community-subscription";
                String path = "events." + type;
                broadcastAlert(
                        replace(config.getString(path + ".message", ""), null, event),
                        replace(config.getString(path + ".boss-bar.message", ""), null, event),
                        path,
                        type);
            });
        }
    }

    private void handleNewFollower(String followerName) {
        String path = "events.new-follower";
        String message = plugin.getTwitchConfig().getString(path + ".message", "").replace("%user%", followerName);
        String boss = plugin.getTwitchConfig().getString(path + ".boss-bar.message", "").replace("%user%", followerName);
        broadcastAlert(message, boss, path, "new-follower");
    }

    private void broadcastMessage(String message) {
        fanout(player -> player.sendMessage(message));
    }

    private void broadcastAlert(String message, String bossMessage, String path, String eventType) {
        FileConfiguration config = plugin.getTwitchConfig();
        String translated = ChatColor.translateAlternateColorCodes('&', message);
        String soundName = config.getString(path + ".sound.name", "").toLowerCase(Locale.ROOT);
        float volume = (float) config.getDouble(path + ".sound.volume", 1.0);
        float pitch = (float) config.getDouble(path + ".sound.pitch", 1.0);
        boolean bossEnabled = config.getBoolean(path + ".boss-bar.enabled", false);
        String bossText = ChatColor.translateAlternateColorCodes('&', bossMessage);
        int duration = config.getInt(path + ".boss-bar.duration", 10);
        BarColor color;
        try {
            color = BarColor.valueOf(config.getString(path + ".boss-bar.color", "WHITE").toUpperCase(Locale.ROOT));
        } catch (IllegalArgumentException error) {
            plugin.getLogger().warning("Invalid boss bar color for Twitch event " + eventType);
            color = BarColor.WHITE;
        }
        BarColor finalColor = color;
        fanout(player -> {
            player.sendMessage(translated);
            if (!soundName.isEmpty()) player.playSound(player.getLocation(), soundName, volume, pitch);
            if (bossEnabled) plugin.getAlertService().showBossBarAlert(player, bossText, finalColor, duration);
        });
    }

    private void fanout(java.util.function.Consumer<Player> action) {
        subscribers.forEach((uuid, player) -> dispatcher.dispatch(player, () -> {
            if (subscribers.containsKey(uuid)) action.accept(player);
        }));
    }

    private String replace(String template, SubscriptionEvent sub, GiftSubscriptionsEvent gift) {
        if (sub != null) {
            return template.replace("%user%", sub.getUser().getName())
                    .replace("%months%", String.valueOf(sub.getMonths()))
                    .replace("%streak%", sub.getSubStreak() == null ? "1" : String.valueOf(sub.getSubStreak()))
                    .replace("%tier%", sub.getSubscriptionPlan())
                    .replace("%gifter%", sub.getGiftedBy() == null ? "" : sub.getGiftedBy().getName())
                    .replace("%recipient%", sub.getUser().getName());
        }
        if (gift != null) {
            return template.replace("%gifter%", gift.getUser().getName())
                    .replace("%count%", String.valueOf(gift.getCount()))
                    .replace("%tier%", gift.getSubscriptionPlan());
        }
        return template;
    }

    private Stream getStream() throws Exception {
        StreamList result = client.getHelix().getStreams(oauthToken, null, null, 1,
                null, null, null, Collections.singletonList(channelName)).execute();
        return result.getStreams().isEmpty() ? null : result.getStreams().getFirst();
    }

    private void runAsync(Runnable runnable) {
        if (plugin.isDisabling()) return;
        if (plugin.isFolia()) Bukkit.getAsyncScheduler().runNow(plugin, ignored -> runnable.run());
        else Bukkit.getScheduler().runTaskAsynchronously(plugin, runnable);
    }
}
