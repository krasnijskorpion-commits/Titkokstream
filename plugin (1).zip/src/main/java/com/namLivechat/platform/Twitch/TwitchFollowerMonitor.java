package com.namLivechat.platform.Twitch;

import com.github.twitch4j.TwitchClient;
import com.github.twitch4j.helix.domain.Follow;
import com.github.twitch4j.helix.domain.FollowList;
import com.namLivechat.NamLivechat;
import io.papermc.paper.threadedregions.scheduler.ScheduledTask;
import org.bukkit.Bukkit;
import org.bukkit.scheduler.BukkitTask;

import java.util.HashSet;
import java.util.Set;
import java.util.concurrent.TimeUnit;
import java.util.function.Consumer;

/** Keeps only the latest API page, so the follower cache is permanently bounded. */
public final class TwitchFollowerMonitor {

    private final NamLivechat plugin;
    private final TwitchClient client;
    private final String oauthToken;
    private final String broadcasterId;
    private final Consumer<String> onNewFollower;
    private final long intervalSeconds;
    private volatile Set<String> knownFollowerIds = Set.of();
    private volatile Object task;

    public TwitchFollowerMonitor(NamLivechat plugin, TwitchClient client, String oauthToken,
                                 String broadcasterId, Consumer<String> onNewFollower,
                                 long intervalSeconds) {
        this.plugin = plugin;
        this.client = client;
        this.oauthToken = oauthToken;
        this.broadcasterId = broadcasterId;
        this.onNewFollower = onNewFollower;
        this.intervalSeconds = intervalSeconds;
    }

    public void start() {
        Runnable check = () -> {
            if (plugin.isDisabling()) {
                stop();
                return;
            }
            try {
                FollowList result = client.getHelix().getFollowers(oauthToken, null, broadcasterId, null, 100).execute();
                if (result == null || result.getFollows() == null) return;
                Set<String> current = new HashSet<>(Math.max(16, result.getFollows().size() * 2));
                for (Follow follower : result.getFollows()) {
                    current.add(follower.getFromId());
                    if (!knownFollowerIds.isEmpty() && !knownFollowerIds.contains(follower.getFromId())) {
                        onNewFollower.accept(follower.getFromName());
                    }
                }
                knownFollowerIds = Set.copyOf(current);
            } catch (Exception error) {
                plugin.logDebug("Twitch follower check failed: " + error.getMessage());
            }
        };

        if (plugin.isFolia()) {
            task = Bukkit.getAsyncScheduler().runAtFixedRate(plugin, ignored -> check.run(),
                    10L, intervalSeconds, TimeUnit.SECONDS);
        } else {
            task = Bukkit.getScheduler().runTaskTimerAsynchronously(plugin, check,
                    200L, intervalSeconds * 20L);
        }
    }

    public void stop() {
        Object current = task;
        task = null;
        if (current instanceof ScheduledTask scheduledTask) scheduledTask.cancel();
        else if (current instanceof BukkitTask bukkitTask) bukkitTask.cancel();
    }
}
