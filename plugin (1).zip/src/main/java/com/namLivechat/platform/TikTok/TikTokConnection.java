package com.namLivechat.platform.TikTok;

import com.namLivechat.NamLivechat;
import com.namLivechat.service.MessageHandler;
import com.namLivechat.service.PlayerTaskDispatcher;
import io.github.jwdeveloper.tiktok.TikTokLive;
import io.github.jwdeveloper.tiktok.data.models.gifts.Gift;
import io.github.jwdeveloper.tiktok.data.models.users.User;
import io.github.jwdeveloper.tiktok.live.LiveClient;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.boss.BarColor;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Player;

import java.util.Locale;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicBoolean;

/** A shared TikTok connection which formats each event once and fans it out. */
public final class TikTokConnection {

    private final NamLivechat plugin;
    private final String username;
    private final TikTokService owner;
    private final MessageHandler messages;
    private final PlayerTaskDispatcher dispatcher;
    private final Map<UUID, Player> subscribers = new ConcurrentHashMap<>();
    private final AtomicBoolean started = new AtomicBoolean();
    private final AtomicBoolean closed = new AtomicBoolean();
    private volatile LiveClient liveClient;
    private volatile String liveTitle;
    private volatile String channelName;

    public TikTokConnection(NamLivechat plugin, String username, TikTokService owner) {
        this.plugin = plugin;
        this.username = username;
        this.owner = owner;
        this.messages = plugin.getMessageHandler();
        this.dispatcher = plugin.getPlayerTaskDispatcher();
    }

    public void addPlayer(Player player) {
        subscribers.put(player.getUniqueId(), player);
        if (channelName != null) notifyConnected(player);
    }

    public void removePlayer(UUID playerId) {
        subscribers.remove(playerId);
        if (subscribers.isEmpty()) stop();
    }

    public void start() {
        if (!started.compareAndSet(false, true)) return;
        runAsync(() -> {
            try {
                liveClient = TikTokLive.newClient(username)
                        .onComment((client, event) -> {
                            FileConfiguration config = plugin.getTiktokConfig();
                            User user = event.getUser();
                            String color = getAuthorColor(user, config);
                            String formatted = config.getString("message-format", "&b[TikTok] %user%: %message%")
                                    .replace("%user%", color + user.getProfileName())
                                    .replace("%message%", event.getText());
                            broadcastMessage(formatted);
                        })
                        .onGift((client, event) -> {
                            FileConfiguration config = plugin.getTiktokConfig();
                            String path = "events.gift";
                            if (!config.getBoolean(path + ".enabled", true)) return;
                            User user = event.getUser();
                            Gift gift = event.getGift();
                            String message = replaceGift(config.getString(path + ".message", ""),
                                    user, gift, event.getCombo());
                            String boss = replaceGift(config.getString(path + ".boss-bar.message", ""),
                                    user, gift, event.getCombo());
                            broadcastAlert(message, boss, path, gift.getName());
                            final int count = Math.max(1,event.getCombo());
                            final long cost = Math.max(0L,(long)gift.getDiamondCost()) * count;
                            fanout(player -> com.namLivechat.service.GiftEffects.play(plugin, player, gift.getName(), cost, count));
                        })
                        .onFollow((client, event) -> {
                            FileConfiguration config = plugin.getTiktokConfig();
                            String path = "events.follow";
                            if (!config.getBoolean(path + ".enabled", true)) return;
                            String name = event.getUser().getProfileName();
                            broadcastAlert(
                                    config.getString(path + ".message", "").replace("%user%", name),
                                    config.getString(path + ".boss-bar.message", "").replace("%user%", name),
                                    path);
                        })
                        .onConnected((client, event) -> {
                            liveTitle = client.getRoomInfo().getTitle();
                            channelName = client.getRoomInfo().getHost().getProfileName();
                            subscribers.values().forEach(this::notifyConnected);
                        })
                        .onLiveEnded((client, event) -> close(true, null))
                        .onError((client, event) -> {
                            String text = event.getException() == null || event.getException().getMessage() == null
                                    ? "" : event.getException().getMessage().toLowerCase(Locale.ROOT);
                            String path;
                            if (text.contains("user not found")) path = "tiktok_user_not_found";
                            else if (text.contains("offline")) path = "tiktok_user_offline";
                            else path = "tiktok_connect_fail";
                            close(false, path);
                        })
                        .build();
                if (closed.get()) {
                    liveClient.disconnect();
                    return;
                }
                liveClient.connect();
            } catch (Exception error) {
                plugin.logDebug("TikTok connection failed for " + username + ": " + error.getMessage());
                close(false, "tiktok_connect_fail");
            }
        });
    }

    public void stop() {
        if (plugin.isDisabling()) close(false, null);
        else runAsync(() -> close(false, null));
    }

    private void notifyConnected(Player player) {
        dispatcher.dispatch(player, () -> {
            if (!subscribers.containsKey(player.getUniqueId())) return;
            messages.sendFormattedMessage(player, "connect_success_tiktok",
                    "%title%", liveTitle,
                    "%user%", channelName);
            player.playSound(player.getLocation(), "entity.experience_orb.pickup", 1.0f, 1.0f);
        });
    }

    private void broadcastMessage(String rawMessage) {
        String message = ChatColor.translateAlternateColorCodes('&', rawMessage);
        fanout(player -> plugin.getHolograms().show(player, message, "comment"));
    }

    private void broadcastAlert(String rawMessage, String rawBossBar, String path) { broadcastAlert(rawMessage,rawBossBar,path,null); }
    private void broadcastAlert(String rawMessage, String rawBossBar, String path, String giftName) {
        FileConfiguration config = plugin.getTiktokConfig();
        String message = ChatColor.translateAlternateColorCodes('&', rawMessage);
        String soundName = config.getString(path + ".sound.name", "").toLowerCase(Locale.ROOT);
        float volume = (float) config.getDouble(path + ".sound.volume", 1.0);
        float pitch = (float) config.getDouble(path + ".sound.pitch", 1.0);
        boolean bossEnabled = config.getBoolean(path + ".boss-bar.enabled", false);
        String bossBar = ChatColor.translateAlternateColorCodes('&', rawBossBar);
        int duration = config.getInt(path + ".boss-bar.duration", 10);
        BarColor color;
        try {
            color = BarColor.valueOf(config.getString(path + ".boss-bar.color", "WHITE").toUpperCase(Locale.ROOT));
        } catch (IllegalArgumentException error) {
            color = BarColor.WHITE;
            plugin.getLogger().warning("Invalid boss bar color in tiktok-config.yml at " + path);
        }
        BarColor finalColor = color;
        fanout(player -> {
            plugin.getHolograms().show(player, message, path.endsWith("gift") ? "gift" : "follow", giftName);
            if (!soundName.isEmpty()) player.playSound(player.getLocation(), soundName, volume, pitch);
            // Alerts are holograms only.
        });
    }

    private void fanout(java.util.function.Consumer<Player> action) {
        subscribers.forEach((uuid, player) -> dispatcher.dispatch(player, () -> {
            if (subscribers.containsKey(uuid)) action.accept(player);
        }));
    }

    private void close(boolean streamEnded, String errorPath) {
        if (!closed.compareAndSet(false, true)) return;
        if (!streamEnded && liveClient != null) {
            try {
                liveClient.disconnect();
            } catch (Exception error) {
                plugin.logDebug("TikTok close failed for " + username + ": " + error.getMessage());
            }
        }
        Map<UUID, Player> snapshot = Map.copyOf(subscribers);
        subscribers.clear();
        owner.connectionClosed(username, this, snapshot.keySet());
        snapshot.values().forEach(player -> dispatcher.dispatch(player, () -> {
            plugin.getAlertService().stopBossBar(player);
            plugin.getHolograms().clear(player.getUniqueId());
            if (streamEnded) {
                messages.sendFormattedMessage(player, "disconnect_stream_ended_tiktok", "%user%", username);
            } else if (errorPath != null) {
                if (errorPath.equals("tiktok_user_not_found") || errorPath.equals("tiktok_user_offline")) {
                    messages.sendFormattedMessage(player, errorPath, "%user%", username);
                } else {
                    messages.sendMessage(player, errorPath);
                }
            }
        }));
    }

    private String replaceGift(String template, User user, Gift gift, int combo) {
        return template.replace("%user%", user.getProfileName())
                .replace("%gift_name%", gift.getName())
                .replace("%amount%", String.valueOf(combo))
                .replace("%total_value%", String.valueOf((long)gift.getDiamondCost()*Math.max(1,combo)));
    }

    private String getAuthorColor(User user, FileConfiguration config) {
        if (user.isModerator()) return config.getString("role-colors.moderator", "&9");
        if (user.isSubscriber()) return config.getString("role-colors.subscriber", "&a");
        return config.getString("role-colors.default", "&7");
    }

    private void runAsync(Runnable runnable) {
        if (plugin.isDisabling()) return;
        if (plugin.isFolia()) Bukkit.getAsyncScheduler().runNow(plugin, ignored -> runnable.run());
        else Bukkit.getScheduler().runTaskAsynchronously(plugin, runnable);
    }
}
