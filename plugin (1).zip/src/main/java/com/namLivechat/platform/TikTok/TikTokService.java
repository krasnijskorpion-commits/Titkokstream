package com.namLivechat.platform.TikTok;

import com.namLivechat.NamLivechat;
import com.namLivechat.service.MessageHandler;
import org.bukkit.entity.Player;

import java.util.ArrayList;
import java.util.Locale;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/** Shares one TikTok WebSocket for all players watching the same creator. */
public final class TikTokService {

    private final NamLivechat plugin;
    private final MessageHandler messages;
    private final Map<UUID, String> playerSessions = new ConcurrentHashMap<>();
    private final Map<String, TikTokConnection> sessions = new ConcurrentHashMap<>();

    public TikTokService(NamLivechat plugin) {
        this.plugin = plugin;
        this.messages = plugin.getMessageHandler();
    }

    public void initialize() { }

    public void start(Player player, String input) {
        if (!plugin.getTiktokConfig().getBoolean("enabled", false)) {
            messages.sendMessage(player, "tiktok_disabled");
            player.playSound(player.getLocation(), "entity.villager.no", 1.0f, 1.0f);
            return;
        }
        if (isConnected(player)) {
            messages.sendFormattedMessage(player, "already_connected", "%platform%", "TikTok");
            return;
        }

        String username = input.startsWith("@") ? input.substring(1) : input;
        username = username.trim().toLowerCase(Locale.ROOT);
        if (!sessions.containsKey(username) && sessions.size() >= maxSessions()) {
            messages.sendMessage(player, "too_many_streams");
            return;
        }
        if (playerSessions.putIfAbsent(player.getUniqueId(), username) != null) return;

        TikTokConnection connection = sessions.computeIfAbsent(username,
                key -> new TikTokConnection(plugin, key, this));
        connection.addPlayer(player);
        connection.start();
    }

    public boolean stop(Player player, boolean silent) {
        String username = playerSessions.remove(player.getUniqueId());
        if (username == null) return false;
        TikTokConnection connection = sessions.get(username);
        if (connection != null) connection.removePlayer(player.getUniqueId());
        plugin.getAlertService().stopBossBar(player);
        plugin.getHolograms().clear(player.getUniqueId());
        return true;
    }

    public void stopAll() {
        new ArrayList<>(sessions.values()).forEach(TikTokConnection::stop);
        playerSessions.clear();
        sessions.clear();
    }

    public boolean isConnected(Player player) {
        return playerSessions.containsKey(player.getUniqueId());
    }

    void connectionClosed(String username, TikTokConnection connection, Iterable<UUID> playerIds) {
        sessions.remove(username, connection);
        playerIds.forEach(uuid -> playerSessions.remove(uuid, username));
    }

    public int getSessionCount() {
        return sessions.size();
    }

    public int getSubscriberCount() {
        return playerSessions.size();
    }

    private int maxSessions() {
        return Math.max(1, plugin.getConfig().getInt("performance.max-shared-streams-per-platform", 50));
    }
}
