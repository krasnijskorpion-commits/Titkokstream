package com.namLivechat.service;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.namLivechat.NamLivechat;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerJoinEvent;

import java.io.File;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.file.AtomicMoveNotSupportedException;
import java.nio.file.Files;
import java.nio.file.StandardCopyOption;
import java.time.Duration;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.TimeUnit;

public class UpdateChecker implements Listener {

    private static final URI LATEST_RELEASE_URI =
            URI.create("https://api.github.com/repos/Nattapat2871/NamLivechat/releases/latest");

    private final NamLivechat plugin;
    private final MessageHandler messageHandler;
    private final File pluginFile;
    private final ObjectMapper objectMapper = new ObjectMapper();
    private final HttpClient httpClient = HttpClient.newBuilder()
            .connectTimeout(Duration.ofSeconds(10))
            .followRedirects(HttpClient.Redirect.NORMAL)
            .build();
    private final Set<UUID> notifiedAdmins = ConcurrentHashMap.newKeySet();

    private volatile String latestVersion;
    private volatile URI downloadUri;
    private volatile boolean updateAvailable;

    public UpdateChecker(NamLivechat plugin) {
        this.plugin = plugin;
        this.messageHandler = plugin.getMessageHandler();
        this.pluginFile = plugin.getPluginFile();
    }

    public void check() {
        if (!plugin.getConfig().getBoolean("update-alert", true)) {
            return;
        }

        runAsyncTask(() -> {
            try {
                HttpRequest request = requestBuilder(LATEST_RELEASE_URI).GET().build();
                HttpResponse<String> response = httpClient.send(request, HttpResponse.BodyHandlers.ofString());
                if (response.statusCode() != 200) {
                    plugin.logDebug("GitHub update check returned HTTP " + response.statusCode());
                    return;
                }

                JsonNode release = objectMapper.readTree(response.body());
                String releaseVersion = release.path("tag_name").asText("").trim();
                if (releaseVersion.isEmpty()) {
                    plugin.logDebug("GitHub update check returned no tag_name.");
                    return;
                }

                latestVersion = releaseVersion;
                downloadUri = findJarDownload(release, releaseVersion);
                updateAvailable = VersionUtils.isNewer(releaseVersion, plugin.getDescription().getVersion());

                if (updateAvailable) {
                    String message = String.format("&a[NamLivechat] &eA new version is available: &6%s", releaseVersion);
                    sendOnSenderThread(
                            Bukkit.getConsoleSender(),
                            () -> Bukkit.getConsoleSender().sendMessage(ChatColor.translateAlternateColorCodes('&', message))
                    );
                }
            } catch (Exception e) {
                plugin.logDebug("Failed to check for updates: " + e.getMessage());
            }
        });
    }

    public void downloadUpdate(CommandSender sender) {
        if (pluginFile == null) {
            messageHandler.sendMessage(sender, "update_fail");
            return;
        }
        if (!updateAvailable) {
            messageHandler.sendMessage(sender, "update_latest");
            return;
        }
        if (downloadUri == null) {
            messageHandler.sendMessage(sender, "update_fail");
            plugin.getLogger().warning("The latest GitHub release does not contain a JAR asset.");
            return;
        }
        if (!plugin.getConfig().getBoolean("auto-update", true)) {
            messageHandler.sendMessage(sender, "update_disabled");
            return;
        }

        messageHandler.sendFormattedMessage(sender, "update_downloading", "%version%", latestVersion);
        plugin.getLogger().info("Update download initiated by " + sender.getName() + " for version " + latestVersion + "...");

        runAsyncTask(() -> {
            File temporaryFile = null;
            try {
                File updateFolder = plugin.getServer().getUpdateFolderFile();
                Files.createDirectories(updateFolder.toPath());

                File downloadedFile = new File(updateFolder, pluginFile.getName());
                temporaryFile = new File(updateFolder, pluginFile.getName() + ".part");

                HttpRequest request = requestBuilder(downloadUri).GET().build();
                HttpResponse<java.nio.file.Path> response = httpClient.send(
                        request,
                        HttpResponse.BodyHandlers.ofFile(temporaryFile.toPath())
                );
                if (response.statusCode() < 200 || response.statusCode() >= 300) {
                    throw new IllegalStateException("GitHub download returned HTTP " + response.statusCode());
                }

                try {
                    Files.move(
                            temporaryFile.toPath(),
                            downloadedFile.toPath(),
                            StandardCopyOption.REPLACE_EXISTING,
                            StandardCopyOption.ATOMIC_MOVE
                    );
                } catch (AtomicMoveNotSupportedException ignored) {
                    Files.move(
                            temporaryFile.toPath(),
                            downloadedFile.toPath(),
                            StandardCopyOption.REPLACE_EXISTING
                    );
                }

                plugin.getLogger().info("Update " + latestVersion + " has been downloaded successfully.");
                plugin.getLogger().info("The new version will be installed automatically on the next server restart.");
                sendOnSenderThread(sender, () -> {
                    messageHandler.sendMessage(sender, "update_success");
                    messageHandler.sendMessage(sender, "update_restart");
                });
            } catch (Exception e) {
                if (temporaryFile != null) {
                    try {
                        Files.deleteIfExists(temporaryFile.toPath());
                    } catch (Exception ignored) {
                        // The incomplete file remains harmless and is replaced on the next attempt.
                    }
                }
                sendOnSenderThread(sender, () -> messageHandler.sendMessage(sender, "update_fail"));
                plugin.getLogger().severe("Update download failed: " + e.getMessage());
            }
        });
    }

    @EventHandler
    public void onPlayerJoin(PlayerJoinEvent event) {
        Player player = event.getPlayer();
        UUID playerUUID = player.getUniqueId();

        if (player.hasPermission("namlivechat.admin") && updateAvailable && notifiedAdmins.add(playerUUID)) {
            Runnable notificationTask = () -> {
                if (player.isOnline()) {
                    messageHandler.sendFormattedMessage(player, "update_available", "%version%", latestVersion);
                    player.playSound(player.getLocation(), "entity.player.levelup", 1.0f, 1.0f);
                }
            };

            if (plugin.isFolia()) {
                player.getScheduler().runDelayed(plugin, task -> notificationTask.run(), null, 100L);
                Bukkit.getAsyncScheduler().runDelayed(
                        plugin,
                        task -> notifiedAdmins.remove(playerUUID),
                        10,
                        TimeUnit.SECONDS
                );
            } else {
                Bukkit.getScheduler().runTaskLater(plugin, notificationTask, 100L);
                Bukkit.getScheduler().runTaskLaterAsynchronously(
                        plugin,
                        () -> notifiedAdmins.remove(playerUUID),
                        200L
                );
            }
        }
    }

    private HttpRequest.Builder requestBuilder(URI uri) {
        return HttpRequest.newBuilder(uri)
                .timeout(Duration.ofSeconds(30))
                .header("Accept", "application/vnd.github+json")
                .header("User-Agent", "NamLivechat/" + plugin.getDescription().getVersion())
                .header("X-GitHub-Api-Version", "2022-11-28");
    }

    private URI findJarDownload(JsonNode release, String releaseVersion) {
        String expectedName = plugin.getDescription().getName() + "-" + releaseVersion + ".jar";
        URI fallback = null;

        for (JsonNode asset : release.path("assets")) {
            String name = asset.path("name").asText("");
            String url = asset.path("browser_download_url").asText("");
            if (url.isEmpty() || !name.toLowerCase(java.util.Locale.ROOT).endsWith(".jar")) {
                continue;
            }
            if (name.equalsIgnoreCase(expectedName)) {
                return URI.create(url);
            }
            if (fallback == null) {
                fallback = URI.create(url);
            }
        }
        return fallback;
    }

    private void sendOnSenderThread(CommandSender sender, Runnable runnable) {
        if (plugin.isDisabling()) {
            return;
        }
        if (sender instanceof Player player) {
            Runnable playerTask = () -> {
                if (player.isOnline()) {
                    runnable.run();
                }
            };
            if (plugin.isFolia()) {
                player.getScheduler().run(plugin, task -> playerTask.run(), null);
            } else {
                Bukkit.getScheduler().runTask(plugin, playerTask);
            }
        } else if (plugin.isFolia()) {
            Bukkit.getGlobalRegionScheduler().run(plugin, task -> runnable.run());
        } else {
            Bukkit.getScheduler().runTask(plugin, runnable);
        }
    }

    private void runAsyncTask(Runnable runnable) {
        if (plugin.isDisabling()) {
            return;
        }
        if (plugin.isFolia()) {
            Bukkit.getAsyncScheduler().runNow(plugin, task -> runnable.run());
        } else {
            Bukkit.getScheduler().runTaskAsynchronously(plugin, runnable);
        }
    }
}
