package com.namLivechat.service;

import com.namLivechat.NamLivechat;
import org.bukkit.*;
import org.bukkit.entity.*;
import org.bukkit.util.Vector;
import java.util.*;

public final class Holograms {
    private final NamLivechat plugin;
    private record Entry(TextDisplay display, long born, int lines) {}
    private final Map<UUID, ArrayDeque<Entry>> entries = new HashMap<>();
    public Holograms(NamLivechat plugin) {
        this.plugin = plugin;
        if (!plugin.getDataFolder().toPath().resolve("gift-icons.tsv").toFile().exists()) plugin.saveResource("gift-icons.tsv", false);
        Bukkit.getScheduler().runTaskTimer(plugin, this::tick, 1L, 2L);
    }
    public void show(Player p, String message, String type) { show(p,message,type,null); }
    public void show(Player p, String message, String type, String giftName) {
        if (!p.isOnline()) return;
        var queue = entries.computeIfAbsent(p.getUniqueId(), k -> new ArrayDeque<>());
        int limit = Math.max(1, Math.min(10, plugin.getConfig().getInt("holograms.max", 5)));
        while (queue.size() >= limit) queue.removeFirst().display().remove();
        String icon = plugin.getConfig().getBoolean("holograms.custom-icons", false)
            ? switch(type) { case "gift" -> "\uE101"; case "follow" -> "\uE102"; default -> "\uE100"; }
            : switch(type) { case "gift" -> "[Gift]"; case "follow" -> "[Follow]"; default -> "[TikTok]"; };
        if (giftName != null && plugin.getConfig().getBoolean("holograms.custom-icons", false)) {
            try { var file = plugin.getDataFolder().toPath().resolve("gift-icons.tsv");
                if (java.nio.file.Files.isRegularFile(file)) {
                    String key = java.text.Normalizer.normalize(giftName, java.text.Normalizer.Form.NFKC).strip().toLowerCase(Locale.ROOT);
                    for (String row : java.nio.file.Files.readAllLines(file)) { String[] parts = row.split("\t",2); if(parts.length==2 && parts[0].equals(key) && parts[1].matches("[\\uE800-\\uFFFF]")) { icon=parts[1]; break; } }
                }
            } catch (java.io.IOException ignored) {}
        }
        String clean = message.replaceAll("[\\p{Cc}\\p{Cf}]", " ");
        if (clean.length() > 220) clean = clean.substring(0, 220);
        String plain = ChatColor.stripColor(clean);
        int width = Math.max(8, Math.min(28, plain.codePointCount(0,plain.length())+3));
        String edge = ChatColor.DARK_AQUA + "━".repeat(width);
        final String text = edge + "\n" + ChatColor.WHITE + icon + " " + clean + "\n" + edge;
        int lines = 2 + Math.max(1, (plain.length()+33)/34);
        TextDisplay d = p.getWorld().spawn(position(p, 0), TextDisplay.class, e -> {
            e.setVisibleByDefault(true); e.setPersistent(false); e.setGravity(false);
            e.setBillboard(Display.Billboard.CENTER); e.setSeeThrough(false);
            e.setShadowed(true); e.setLineWidth(180); e.setBackgroundColor(Color.fromARGB(175, 15, 15, 20));
            e.setDefaultBackground(false); e.setText(text); e.setTeleportDuration(2);
        });

        queue.addLast(new Entry(d, System.currentTimeMillis(), lines));
    }
    private Location position(Player p, double height) {
        double angle = java.util.concurrent.ThreadLocalRandom.current().nextDouble(2*Math.PI);
        double radius = java.util.concurrent.ThreadLocalRandom.current().nextDouble(1.5,3.0);
        return p.getLocation().add(Math.cos(angle)*radius, 1.2+java.util.concurrent.ThreadLocalRandom.current().nextDouble(0.7), Math.sin(angle)*radius);
    }
    private void tick() {
        long now = System.currentTimeMillis();
        long life = 1000L * Math.max(2, Math.min(60, plugin.getConfig().getInt("holograms.seconds", 5)));
        for (var it = entries.entrySet().iterator(); it.hasNext();) {
            var group = it.next(); Player p = Bukkit.getPlayer(group.getKey()); var q = group.getValue();
            if (p == null || !p.isOnline()) { q.forEach(e -> e.display().remove()); it.remove(); continue; }
            q.removeIf(e -> { boolean expired = !e.display().isValid() || now-e.born()>=life; if(expired)e.display().remove(); return expired; });
            for (Entry e : q) {
                double age=now-e.born(); double alpha=Math.max(0,Math.min(1,(life-age)/700.0));
                e.display().setTextOpacity((byte)Math.max(4,(int)(255*alpha)));
                e.display().setBackgroundColor(Color.fromARGB((int)(175*alpha),15,15,20));
            }
            if(q.isEmpty())it.remove();
        }
    }
    public void clear(UUID id) { var q=entries.remove(id); if(q!=null)q.forEach(e->e.display().remove()); }
    public void shutdown() { for(UUID id:new ArrayList<>(entries.keySet()))clear(id); }
}
