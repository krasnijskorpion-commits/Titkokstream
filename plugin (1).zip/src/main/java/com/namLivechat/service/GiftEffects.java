package com.namLivechat.service;
import com.namLivechat.NamLivechat;
import org.bukkit.*;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitRunnable;
public final class GiftEffects {
    public static void play(NamLivechat plugin, Player player, String name, long cost, int count) {
        if (!player.isOnline() || !plugin.getConfig().getBoolean("gift-effects.enabled",true)) return;
        var names = plugin.getConfig().getStringList("gift-effects.team-heart-names");
        if (name != null && (name.equalsIgnoreCase("Team Heart") || names.stream().anyMatch(n -> n.equalsIgnoreCase(name)))) {
            player.setFoodLevel(20); player.setSaturation(20); player.giveExpLevels(Math.min(100,Math.max(1,count)));
        }
        int tier = cost >= 5000 ? 7 : cost >= 1000 ? 6 : cost >= 500 ? 5 : cost >= 100 ? 4 : cost >= 50 ? 3 : cost >= 10 ? 2 : cost >= 2 ? 1 : 0;
        Location center = player.getLocation().add(0,1,0);
        center.getWorld().spawnParticle(tier == 0 ? Particle.POOF : Particle.FIREWORK,center,8+tier*8,0.4,0.5,0.4,0.04);
        if(tier < 2) return;
        new BukkitRunnable() {
            int frame=0;
            public void run() {
                if(!player.isOnline() || frame >= 3+tier*2) { cancel(); return; }
                Location l=player.getLocation();
                if(tier>=5 && frame==0) l.getWorld().spawnParticle(Particle.FLASH,l.clone().add(0,2,0),1);
                for(int i=0;i<12+tier*3;i++) {
                    double a=i*2*Math.PI/(12+tier*3)+frame*0.35;
                    double r=0.8+tier*0.22+(tier>=4?frame*0.09:0);
                    Location at=l.clone().add(Math.cos(a)*r,0.5+(tier>=5?frame*0.14:0.4),Math.sin(a)*r);
                    l.getWorld().spawnParticle(Particle.FIREWORK,at,1,0,0,0,0.01);
                }
                frame++;
            }
        }.runTaskTimer(plugin,0L,3L);
    }
}
