package com.namLivechat.service;

import com.namLivechat.NamLivechat;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitTask;

import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.LongAdder;

/**
 * Applies bounded backpressure to all messages entering the Minecraft thread.
 * Paper uses one shared tick task; Folia schedules at most one entity task per
 * player and burst, preserving region ownership without flooding schedulers.
 */
public final class PlayerTaskDispatcher {

    private final NamLivechat plugin;
    private final boolean folia;
    private final Map<UUID, QueueState> queues = new ConcurrentHashMap<>();
    private final LongAdder droppedTasks = new LongAdder();
    private final LongAdder executedTasks = new LongAdder();
    private volatile int capacity;
    private volatile int tasksPerTick;
    private BukkitTask paperTicker;

    public PlayerTaskDispatcher(NamLivechat plugin) {
        this.plugin = plugin;
        this.folia = plugin.isFolia();
        reloadSettings();
        if (!folia) {
            paperTicker = Bukkit.getScheduler().runTaskTimer(plugin, this::tickPaper, 1L, 1L);
        }
    }

    public void reloadSettings() {
        capacity = clamp(plugin.getConfig().getInt("performance.message-queue-capacity", 200), 20, 10_000);
        tasksPerTick = clamp(plugin.getConfig().getInt("performance.messages-per-tick", 20), 1, 1_000);
    }

    public boolean dispatch(Player player, Runnable task) {
        if (plugin.isDisabling() || player == null || !player.isOnline()) return false;

        QueueState state = queues.compute(player.getUniqueId(), (uuid, current) -> {
            QueueState target = current == null || current.player != player
                    ? new QueueState(player)
                    : current;
            if (target.queue.offer(task, capacity)) droppedTasks.increment();
            return target;
        });
        if (folia) scheduleFolia(state);
        return true;
    }

    public void clearPlayer(UUID playerId) {
        QueueState state = queues.remove(playerId);
        if (state != null) state.queue.clear();
    }

    public void shutdown() {
        if (paperTicker != null) {
            paperTicker.cancel();
            paperTicker = null;
        }
        queues.values().forEach(state -> state.queue.clear());
        queues.clear();
    }

    public long getDroppedTasks() {
        return droppedTasks.sum();
    }

    public long getExecutedTasks() {
        return executedTasks.sum();
    }

    public int getQueuedTasks() {
        return queues.values().stream().mapToInt(state -> state.queue.size()).sum();
    }

    public int getActiveQueues() {
        return queues.size();
    }

    private void tickPaper() {
        queues.forEach((uuid, state) -> {
            if (!state.player.isOnline()) {
                clearPlayer(uuid);
                return;
            }
            drain(state);
            queues.computeIfPresent(uuid, (ignored, current) ->
                    current == state && current.queue.isEmpty() ? null : current);
        });
    }

    private void scheduleFolia(QueueState state) {
        if (!state.scheduled.compareAndSet(false, true)) return;
        state.player.getScheduler().runDelayed(plugin, ignored -> {
            drain(state);
            state.scheduled.set(false);
            if (!state.queue.isEmpty()) scheduleFolia(state);
            else queues.computeIfPresent(state.player.getUniqueId(), (ignoredId, current) ->
                    current == state && current.queue.isEmpty() ? null : current);
        }, () -> clearPlayer(state.player.getUniqueId()), 1L);
    }

    private void drain(QueueState state) {
        for (int i = 0; i < tasksPerTick; i++) {
            Runnable task = state.queue.poll();
            if (task == null) return;
            try {
                if (state.player.isOnline()) task.run();
            } catch (Throwable error) {
                plugin.getLogger().warning("Queued live-chat task failed: " + error.getMessage());
            } finally {
                executedTasks.increment();
            }
        }
    }

    private static int clamp(int value, int min, int max) {
        return Math.max(min, Math.min(max, value));
    }

    private static final class QueueState {
        private final Player player;
        private final BoundedTaskQueue queue = new BoundedTaskQueue();
        private final AtomicBoolean scheduled = new AtomicBoolean();

        private QueueState(Player player) {
            this.player = player;
        }
    }
}
