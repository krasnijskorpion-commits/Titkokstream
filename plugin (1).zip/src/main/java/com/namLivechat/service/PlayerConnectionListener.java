package com.namLivechat.service;

import com.namLivechat.NamLivechat;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerQuitEvent;

/** Ensures upstream sessions and queued work never retain offline players. */
public final class PlayerConnectionListener implements Listener {

    private final NamLivechat plugin;

    public PlayerConnectionListener(NamLivechat plugin) {
        this.plugin = plugin;
    }

    @EventHandler(priority = EventPriority.MONITOR)
    public void onQuit(PlayerQuitEvent event) {
        Player player = event.getPlayer();
        plugin.getYoutubeService().stop(player, true);
        plugin.getTwitchService().stop(player, true);
        plugin.getTiktokService().stop(player, true);
        plugin.getAlertService().stopBossBar(player);
        plugin.getPlayerTaskDispatcher().clearPlayer(player.getUniqueId());
    }
}
