package com.namLivechat.service;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

final class VersionUtils {

    private VersionUtils() {
    }

    static boolean isNewer(String candidate, String current) {
        ParsedVersion candidateVersion = ParsedVersion.parse(candidate);
        ParsedVersion currentVersion = ParsedVersion.parse(current);
        return candidateVersion.compareTo(currentVersion) > 0;
    }

    private record ParsedVersion(List<Integer> numbers, String qualifier) implements Comparable<ParsedVersion> {

        private static ParsedVersion parse(String value) {
            String normalized = value == null ? "" : value.trim().toLowerCase(Locale.ROOT);
            if (normalized.startsWith("v")) {
                normalized = normalized.substring(1);
            }
            normalized = normalized.split("\\+", 2)[0];

            String[] versionAndQualifier = normalized.split("-", 2);
            String[] parts = versionAndQualifier[0].split("\\.");
            List<Integer> numbers = new ArrayList<>(parts.length);
            for (String part : parts) {
                try {
                    numbers.add(Integer.parseInt(part.replaceFirst("[^0-9].*$", "")));
                } catch (NumberFormatException ignored) {
                    numbers.add(0);
                }
            }

            String qualifier = versionAndQualifier.length == 2 ? versionAndQualifier[1] : "";
            return new ParsedVersion(List.copyOf(numbers), qualifier);
        }

        @Override
        public int compareTo(ParsedVersion other) {
            int length = Math.max(numbers.size(), other.numbers.size());
            for (int index = 0; index < length; index++) {
                int left = index < numbers.size() ? numbers.get(index) : 0;
                int right = index < other.numbers.size() ? other.numbers.get(index) : 0;
                int comparison = Integer.compare(left, right);
                if (comparison != 0) {
                    return comparison;
                }
            }

            if (qualifier.isEmpty() && !other.qualifier.isEmpty()) {
                return 1;
            }
            if (!qualifier.isEmpty() && other.qualifier.isEmpty()) {
                return -1;
            }
            return compareQualifiers(qualifier, other.qualifier);
        }

        private static int compareQualifiers(String leftQualifier, String rightQualifier) {
            String[] leftParts = leftQualifier.split("[.-]");
            String[] rightParts = rightQualifier.split("[.-]");
            int commonLength = Math.min(leftParts.length, rightParts.length);

            for (int index = 0; index < commonLength; index++) {
                String left = leftParts[index];
                String right = rightParts[index];
                boolean leftNumeric = left.matches("\\d+");
                boolean rightNumeric = right.matches("\\d+");

                int comparison;
                if (leftNumeric && rightNumeric) {
                    comparison = new BigInteger(left).compareTo(new BigInteger(right));
                } else if (leftNumeric != rightNumeric) {
                    comparison = leftNumeric ? -1 : 1;
                } else {
                    comparison = left.compareTo(right);
                }

                if (comparison != 0) {
                    return comparison;
                }
            }

            return Integer.compare(leftParts.length, rightParts.length);
        }
    }
}
