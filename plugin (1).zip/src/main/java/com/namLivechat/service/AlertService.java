package com.namLivechat.service;

import com.namLivechat.NamLivechat;
import io.papermc.paper.threadedregions.scheduler.ScheduledTask;
import org.bukkit.Bukkit;
import org.bukkit.boss.BarColor;
import org.bukkit.boss.BarStyle;
import org.bukkit.boss.BossBar;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitTask;

import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/** Maintains boss bars with one low-frequency ticker instead of one 20 Hz task per bar. */
public final class AlertService {

    private final NamLivechat plugin;
    private final boolean folia;
    private final Map<UUID, AlertState> alerts = new ConcurrentHashMap<>();
    private volatile long updateIntervalTicks;
    private BukkitTask paperTicker;

    public AlertService(NamLivechat plugin) {
        this.plugin = plugin;
        this.folia = plugin.isFolia();
        reloadSettings();
        startPaperTicker();
    }

    public void reloadSettings() {
        updateIntervalTicks = Math.max(1L, Math.min(20L,
                plugin.getConfig().getLong("performance.bossbar-update-interval-ticks", 5L)));
        if (!folia && paperTicker != null) {
            paperTicker.cancel();
            startPaperTicker();
        }
    }

    public void showBossBarAlert(Player player, String title, BarColor color, int durationSeconds) {
        stopBossBar(player);
        if (durationSeconds <= 0 || !player.isOnline()) return;

        BossBar bossBar = Bukkit.createBossBar(title, color, BarStyle.SOLID);
        bossBar.setProgress(1.0);
        bossBar.addPlayer(player);

        long durationNanos = durationSeconds * 1_000_000_000L;
        AlertState state = new AlertState(player, bossBar, System.nanoTime(), durationNanos);
        alerts.put(player.getUniqueId(), state);

        if (folia) {
            state.task = player.getScheduler().runAtFixedRate(plugin,
                    ignored -> tick(state),
                    () -> removeState(player.getUniqueId(), state),
                    updateIntervalTicks,
                    updateIntervalTicks);
        }
    }

    public void stopBossBar(Player player) {
        AlertState state = alerts.remove(player.getUniqueId());
        if (state != null) closeState(state);
    }

    public int getActiveBossBars() {
        return alerts.size();
    }

    public void shutdown() {
        if (paperTicker != null) {
            paperTicker.cancel();
            paperTicker = null;
        }
        alerts.values().forEach(this::closeState);
        alerts.clear();
    }

    private void startPaperTicker() {
        if (!folia && plugin.isEnabled()) {
            paperTicker = Bukkit.getScheduler().runTaskTimer(plugin,
                    () -> alerts.values().forEach(this::tick),
                    updateIntervalTicks,
                    updateIntervalTicks);
        }
    }

    private void tick(AlertState state) {
        if (!state.player.isOnline()) {
            removeState(state.player.getUniqueId(), state);
            return;
        }

        double elapsed = (double) (System.nanoTime() - state.startedNanos) / state.durationNanos;
        if (elapsed >= 1.0) {
            removeState(state.player.getUniqueId(), state);
        } else {
            state.bossBar.setProgress(Math.max(0.0, Math.min(1.0, 1.0 - elapsed)));
        }
    }

    private void removeState(UUID playerId, AlertState expected) {
        if (alerts.remove(playerId, expected)) closeState(expected);
    }

    private void closeState(AlertState state) {
        Object task = state.task;
        state.task = null;
        if (task instanceof BukkitTask bukkitTask) bukkitTask.cancel();
        else if (task instanceof ScheduledTask scheduledTask) scheduledTask.cancel();
        state.bossBar.removeAll();
    }

    private static final class AlertState {
        private final Player player;
        private final BossBar bossBar;
        private final long startedNanos;
        private final long durationNanos;
        private volatile Object task;

        private AlertState(Player player, BossBar bossBar, long startedNanos, long durationNanos) {
            this.player = player;
            this.bossBar = bossBar;
            this.startedNanos = startedNanos;
            this.durationNanos = durationNanos;
        }
    }
}
