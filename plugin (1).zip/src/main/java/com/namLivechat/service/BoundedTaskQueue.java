package com.namLivechat.service;

import java.util.ArrayDeque;

/**
 * Small synchronized queue which always keeps the newest work. This prevents a
 * burst from an upstream chat from growing an unbounded server task backlog.
 */
final class BoundedTaskQueue {

    private final ArrayDeque<Runnable> tasks = new ArrayDeque<>();

    synchronized boolean offer(Runnable task, int capacity) {
        boolean dropped = false;
        if (tasks.size() >= capacity) {
            tasks.pollFirst();
            dropped = true;
        }
        tasks.offerLast(task);
        return dropped;
    }

    synchronized Runnable poll() {
        return tasks.pollFirst();
    }

    synchronized int size() {
        return tasks.size();
    }

    synchronized boolean isEmpty() {
        return tasks.isEmpty();
    }

    synchronized void clear() {
        tasks.clear();
    }
}
