package com.namLivechat.command;

import com.namLivechat.NamLivechat;
import com.namLivechat.service.MessageHandler;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;

public class AdminCommand implements CommandExecutor {

    private final NamLivechat plugin;
    private final MessageHandler messageHandler;

    public AdminCommand(NamLivechat plugin) {
        this.plugin = plugin;
        this.messageHandler = plugin.getMessageHandler();
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (args.length == 0) {
            showPluginInfo(sender);
            return true;
        }

        if (!sender.hasPermission("namlivechat.admin")) {
            messageHandler.sendMessage(sender, "no_permission");
            return true;
        }

        String subCommand = args[0].toLowerCase();
        switch (subCommand) {
            case "reload":
                plugin.reloadPlugin();
                messageHandler.sendMessage(sender, "admin_reload");
                break;

            case "update":
                plugin.getUpdateChecker().downloadUpdate(sender);
                break;

            case "stats":
                messageHandler.sendMessage(sender, "stats_header");
                messageHandler.sendFormattedMessage(sender, "stats_platform",
                        "%platform%", "YouTube",
                        "%sessions%", String.valueOf(plugin.getYoutubeService().getSessionCount()),
                        "%subscribers%", String.valueOf(plugin.getYoutubeService().getSubscriberCount()));
                messageHandler.sendFormattedMessage(sender, "stats_platform",
                        "%platform%", "Twitch",
                        "%sessions%", String.valueOf(plugin.getTwitchService().getSessionCount()),
                        "%subscribers%", String.valueOf(plugin.getTwitchService().getSubscriberCount()));
                messageHandler.sendFormattedMessage(sender, "stats_platform",
                        "%platform%", "TikTok",
                        "%sessions%", String.valueOf(plugin.getTiktokService().getSessionCount()),
                        "%subscribers%", String.valueOf(plugin.getTiktokService().getSubscriberCount()));
                messageHandler.sendFormattedMessage(sender, "stats_queue",
                        "%queued%", String.valueOf(plugin.getPlayerTaskDispatcher().getQueuedTasks()),
                        "%queues%", String.valueOf(plugin.getPlayerTaskDispatcher().getActiveQueues()),
                        "%processed%", String.valueOf(plugin.getPlayerTaskDispatcher().getExecutedTasks()),
                        "%dropped%", String.valueOf(plugin.getPlayerTaskDispatcher().getDroppedTasks()),
                        "%bossbars%", String.valueOf(plugin.getAlertService().getActiveBossBars()));
                break;

            default:
                messageHandler.sendMessage(sender, "admin_usage");
                break;
        }
        return true;
    }

    private void showPluginInfo(CommandSender sender) {
        messageHandler.sendFormattedMessage(sender, "plugin_info_header",
                "%version%", plugin.getDescription().getVersion());
        messageHandler.sendMessage(sender, "plugin_info_description");
        messageHandler.sendMessage(sender, "plugin_info_platforms");
        messageHandler.sendMessage(sender, "plugin_info_author");
        messageHandler.sendMessage(sender, "plugin_info_usage");
    }
}
