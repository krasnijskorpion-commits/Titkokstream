package com.namLivechat.service;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

class VersionUtilsTest {

    @Test
    void detectsNewerVersionsWithDifferentSegmentCounts() {
        assertTrue(VersionUtils.isNewer("1.2.0", "1.1"));
        assertTrue(VersionUtils.isNewer("v2.0", "1.99.99"));
    }

    @Test
    void treatsEquivalentVersionsAsCurrent() {
        assertFalse(VersionUtils.isNewer("v1.2.0", "1.2"));
        assertFalse(VersionUtils.isNewer("1.2.0+build.4", "1.2.0"));
    }

    @Test
    void treatsStableReleaseAsNewerThanPrerelease() {
        assertTrue(VersionUtils.isNewer("1.2.0", "1.2.0-beta.1"));
        assertFalse(VersionUtils.isNewer("1.2.0-beta.1", "1.2.0"));
        assertTrue(VersionUtils.isNewer("1.2.0-beta.10", "1.2.0-beta.2"));
    }
}
