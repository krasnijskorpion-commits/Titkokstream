package com.namLivechat.service;

import org.junit.jupiter.api.Test;

import java.util.concurrent.CountDownLatch;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicInteger;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

class BoundedTaskQueueTest {

    @Test
    void burstRemainsBoundedAndKeepsNewestTasks() {
        BoundedTaskQueue queue = new BoundedTaskQueue();
        AtomicInteger last = new AtomicInteger(-1);
        int dropped = 0;

        for (int i = 0; i < 100_000; i++) {
            int value = i;
            if (queue.offer(() -> last.set(value), 200)) dropped++;
        }

        assertEquals(200, queue.size());
        assertEquals(99_800, dropped);
        Runnable task;
        while ((task = queue.poll()) != null) task.run();
        assertEquals(99_999, last.get());
    }

    @Test
    void concurrentProducersNeverExceedCapacity() throws Exception {
        BoundedTaskQueue queue = new BoundedTaskQueue();
        int producers = 8;
        ExecutorService executor = Executors.newFixedThreadPool(producers);
        CountDownLatch ready = new CountDownLatch(producers);
        CountDownLatch start = new CountDownLatch(1);

        for (int producer = 0; producer < producers; producer++) {
            executor.submit(() -> {
                ready.countDown();
                try {
                    start.await();
                    for (int i = 0; i < 25_000; i++) queue.offer(() -> { }, 256);
                } catch (InterruptedException interrupted) {
                    Thread.currentThread().interrupt();
                }
            });
        }

        assertTrue(ready.await(5, TimeUnit.SECONDS));
        start.countDown();
        executor.shutdown();
        assertTrue(executor.awaitTermination(10, TimeUnit.SECONDS));
        assertEquals(256, queue.size());
    }
}
